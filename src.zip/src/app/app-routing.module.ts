import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { ContactComponent } from './contact/contact.component';
import { ProfileComponent } from './profile/profile.component';
import { ProductComponent } from './product/product.component';
import { AboutComponent } from './about/about.component';
import { EmployeeComponent } from './employee/employee.component';




const routes: Routes = [
  {path:'', redirectTo:'home', pathMatch:'full'},
  {path:'home',component:HomeComponent},
  {path:'about', component:AboutComponent, children:[{path:'',redirectTo:'profile',pathMatch:'full'},
    {path:'profile',component:ProfileComponent},
    {path:'contact',component:ContactComponent},
    {path:'employee',component:EmployeeComponent},
    {path:'product',component:ProductComponent}]},
  {path:'employee', component:EmployeeComponent},
  {path:'product', component:ProductComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

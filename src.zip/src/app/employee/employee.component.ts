import { Component } from '@angular/core';
import { Person } from '../person';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent {
  employees : Person[] = [
    {id:10001, name:"John", dept:"Dev"},
    {id:10002, name:"Rose", dept:"QA"},
    {id:10003, name:"Vijay", dept:"IT"},
    {id:10004, name:"Vikram", dept:"Dev"},
    {id:10005, name:"Ram", dept:"Dev"}
  ];

  show1: Boolean = true;
}

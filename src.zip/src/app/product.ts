export class Product {

    productName : String;
    productId: number;
    productPrice: number;
    productQty: number;

    constructor(productId: number, productName: String, productPrice: number, productQty: number)
    {
        this.productId = productId;
        this.productName = productName;
        this.productPrice = productPrice;
        this.productQty = productQty;
    }
}

import { Component } from '@angular/core';
import { Product } from '../product';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent {
  products : Product[] = [
    {productId:10001, productName:"Trampoline", productPrice:10.99, productQty:20},
    {productId:10002, productName:"Jeans", productPrice: 19.99, productQty:15},
    {productId:10003, productName:"T-shirt", productPrice: 9.99, productQty:10},
    {productId:10004, productName:"Salmon", productPrice: 6.99, productQty:5},
    {productId:10005, productName:"Monopoly", productPrice: 11.99, productQty:8}
  ];
  show1: Boolean = true;
}
